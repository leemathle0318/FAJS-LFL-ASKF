#include "../core/PendingFrames.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <deque>
#include <cstdio>
static unsigned run(bool oldPolicy) {
    std::deque<double> queue; unsigned published = 0;
    for (unsigned i = 0; i < 300; ++i) {
        double now = double(i)/60;
        if (oldPolicy) {
            queue.push_back(now+.180);
            while (queue.size() > 6) queue.pop_front();
        } else obs::enqueuePending(queue, now+.180);
        bool ready = false;
        while (!queue.empty() && queue.front() <= now) { ready = true; queue.pop_front(); }
        if (ready) ++published;
    }
    return published;
}
int main() {
    assert(run(true) == 0); // reproduce eviction before eligibility
    assert(run(false) > 250);
    std::deque<int> queue;
    for (unsigned i = 0; i < obs::MaximumPendingFrames; ++i) assert(obs::enqueuePending(queue, int(i)));
    assert(!obs::enqueuePending(queue, 999));
    assert(queue.front() == 0 && queue.back() == int(obs::MaximumPendingFrames-1));
    std::printf("PASS: old 6-frame/180-ms queue reproduces zero publications at 60 FPS; bounded replacement publishes %u\n", run(false));
}
