#pragma once
#include <cstdint>
namespace obs {
enum class AccessPhase : uint32_t { Unrequested, Requesting, LibraryMissing, SymbolMissing,
    ProfileRejected, ReadProbeFailed, HeaderMismatch, Verified, Exhausted };
struct AccessAttempt {
    uint64_t session = 0;
    unsigned attempts = 0;
    bool verified = false;
    AccessPhase phase = AccessPhase::Unrequested;
    int detail = 0;
    bool begin(uint64_t value) {
        if (!value) return false;
        if (value != session) { session = value; attempts = 0; verified = false; phase = AccessPhase::Unrequested; detail = 0; }
        if (verified || attempts >= 3) return false;
        ++attempts; phase = AccessPhase::Requesting; detail = int(attempts); return true;
    }
    void finish(AccessPhase result, int code) {
        phase = result; detail = code; verified = result == AccessPhase::Verified;
    }
    uint64_t state() const { return (uint64_t(phase) << 32) | uint32_t(detail); }
};
}
