# OBSBridge 0.2.4：接入现成 libSandy 文件授权组件

**源码修正版，不是已经通过手机直播验收的可用成品。** 目标仍为 rootless / iOS 15.0–16.6；已知测试手机为 8 Plus / 15.0.2。没有连接手机，本机检查不能确认真实画面替换、OBS 声音与手机麦克风混音。

## 本次仅修打包失败

用户 Actions 截图显示两个 dylib 与设置 bundle 均完成编译/链接/签名，deb 也已生成，随后被严格属主检查拒绝；不是编译错误。

固定版本 Theos 的 dm.pl 在非 root 分支只调用 chown(root,wheel) 设置 tar 的名称字段。Archive::Tar::File 的 chown 不设置数字 uid/gid，因此 tar 仍可能保留构建用户数字标识。本次对固定 SHA-256 的打包器仅补 numeric uid(0)/gid(0)，并在 before-package 中把单个 profile 转成二进制、固定为 0644。

不使用 sudo、没有递归 chown/chmod、没有关闭检查。版本仍是 0.2.4，摄像头、音频、网络代码未改。GitHub 新增真实固定 dm.pl 的合成包回归，在正式构建前比较修复前后 tar 元数据和 payload 内容。

## 针对哪一步

用户 0.2.3 截图 IMG_0085 显示：TCP、H.264/AAC 解码、共享发布均工作；系统媒体视频/音频回调存在，但 `open(RO) errno=1`，实际替换/混音为 0。只读也打不开缓存。这是当前断点，不需要重测网络或修改 OBS 已连通的设置。

此前没有核实媒体进程的跨进程读取授权就连续给出修正版，不足以交付用户要求的功能。本次读取公开实现后，直接调用 [opa334/libSandy](https://github.com/opa334/libSandy) 的公开接口，不再自行猜测 chmod/路径能解决权限问题。

## 本版改变

- 增加外部依赖 `com.opa334.libsandy (>= 1.1.2)`，通过 rootless 库调用 `libSandy_applyProfile`。不捆绑来历不明的 libSandy 二进制。
- profile 仅允许 `com.apple.mediaserverd` 申请插件自有缓存文件的只读访问；没有通配进程、没有整个目录/根目录的权限、没有读写权限。
- profile 在 `/var/jb/Library/libSandy/local.xiaoguai.obsbridge.media-read.plist`，构建产物检查必须为 root:root、不可由组/其他用户写入。
- 在独立后台队列申请，摄像头/麦克风回调不等待授权通信。每个缓存会话最多尝试 3 次，不无限重试。
- 库返回成功后，仍实际检查只读打开、只读映射和协议/会话匹配。仅凭接口返回 0 不标记成功。
- 保留已通过用户设备证据的 TCP 接收、H.264/AAC 解码与发布；保持原系统媒体节点替换/混音实现，不添加目标应用注入。

这补上了明确的授权环节，但该设备的媒体进程是否接受扩展、是否能联系授权服务，仍需真实运行证据。**不承诺此次一定替换成功。** 公开源码审查见 SOURCE_REVIEW.md。

## 构建与依赖

1. 将 `OBSBridge-source-0.2.4-packaging-fix.zip` 原文件上传仓库，不必解压上传文件夹。
2. 用配套“GitHub工作流-0.2.4打包属主修正版.txt”内容覆盖仓库根 `.github/workflows/build-deb.yml`。ZIP 内文件不会自动替换仓库工作流。
3. 提交后运行新的 Actions；下载 `OBSBridge-rootless-deb`，不要用旧运行的产物。
4. 安装时由包管理器解决适合当前 rootless 环境的 libSandy 依赖。若显示缺少依赖，停止安装，不使用忽略依赖强制安装、不下载旧 rootful 包凑数。
5. 包 ID 未变，可升级覆盖。两模块需重新加载；使用 Dopamine 重启用户空间，不只刷新桌面。

依赖作者仓库：[opa334](https://opa334.github.io/)。必须选择包管理器为当前越狱环境提供的兼容构建。完整 Theos/macOS 编译、链接、签名仍由 Actions 实际执行；本机只做了 arm64 对象编译等检查。

## 状态如何判定

解锁，短按音量上再在 0.8 秒内短按音量下。保留已有 OBS URL、MPEG-TS、H.264/AAC 设置。

- “libSandy：实际只读打开、映射和协议检查通过”只代表缓存读取通了，不等于画面/声音通过。
- “返回 1”表示授权通信失败；“返回 2”表示 profile/进程标识/条件等拒绝；“返回 0，但探测失败”仍不是成功。不要用 `*` 放宽 profile 或 chmod 777。
- 真正完成必须同时有实际 OBS 画面、实际替换计数增长，短录像回听 OBS 声音和手机真实环境音；TikTok 观众端仍需单独验证。
- 无数据、格式不支持或失败时透传真摄像头和麦克风。本插件不是隐私遮挡工具。

## 已检查 / 未验证

见 TEST_RESULTS.md。缓存约 11.3 MiB，包含最近媒体，未加密；停止会清当前可写槽和 PCM，但不保证清除崩溃残留/文件系统快照。只在可信局域网使用，禁止公网开放 TCP 5000。长时间写回、耗电、性能、音画同步未验证。

格式支持限有界 BGRA/8-bit NV12 与 packed Float32/Int16 PCM；不承诺照片、HDR、深度、AR、电话等路径。FFmpeg 的 LGPL 材料与外部依赖说明见 THIRD_PARTY.md。
