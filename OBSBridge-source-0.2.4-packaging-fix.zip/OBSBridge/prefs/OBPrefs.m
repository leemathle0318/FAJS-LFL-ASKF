#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import "../Shared.h"
#import "../Client.h"
@interface OBPrefs : PSListController
@end
@implementation OBPrefs
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (id)readPreferenceValue:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (![key isKindOfClass:NSString.class]) return nil;
    return [key isEqualToString:@"PCIP"] ? OBCPeerIP() : [specifier propertyForKey:@"default"];
}
- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (![key isEqualToString:@"PCIP"] || ![value isKindOfClass:NSString.class]) return;
    NSString *error = OBCSavePeerIP(value);
    if (error) [self message:error];
}
- (void)message:(NSString *)text {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"OBS 摄像头"
        message:text preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (BOOL)command:(BOOL)enabled {
    [self.view endEditing:YES];
    NSString *error = OBCSendCommand(enabled, OBCPeerIP());
    if (error) { [self message:error]; return NO; }
    return YES;
}
- (void)startLive {
    if ([self command:YES]) [self message:[NSString stringWithFormat:
        @"已发送启动请求（不是启动成功证明）。\n先查看状态，确认系统接口已挂接。\nOBS 地址：%@\n该操作会影响系统摄像头采集链路；断流时支持的画面格式输出黑屏。", OBCURL()]];
}
- (void)stopLive { if ([self command:NO]) [self message:@"已发送停止请求，请查看状态确认已恢复。"]; }
- (void)copyURL {
    NSString *url = OBCURL();
    if (!url) { [self message:@"未找到 Wi-Fi IPv4 地址"]; return; }
    UIPasteboard.generalPasteboard.string = url;
    [self message:@"手机 TCP 地址已复制"]; 
}
- (void)showStatus {
    [self message:OBCStatus()];
}
@end
