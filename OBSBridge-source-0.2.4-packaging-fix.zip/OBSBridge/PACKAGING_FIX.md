# 0.2.4 打包属主修正

本次修改仅解决 Actions 的 libSandy profile 包元数据检查失败，不声称修复或验证手机摄像头和声音。

依据：Theos 固定提交 304e0799973e8145f32e4ca2de6c747a84b758ce 的 dm.pl 子模块 d9a3b72e274226dd2823c0a7c1d6d05099f4f51c；原 dm.pl SHA256 a750fda6e9a2306b6c2b8b099e21aeca56b314179c0cd3b73c7c8636b32f5d41。

原代码非 root 分支仅改 tar 属主名称，没改数字 UID/GID。修复只补数字 UID/GID 为 0；遇到未知版本立即失败，不模糊替换。重复运行不会重复加补丁。配置在打包前转为二进制并固定 0644，避免后续转换重新创建权限。最终 deb 检查继续要求数字 root:root、禁止组/其他用户写入，失败会打印实际 uid/gid/mode。

本机：新增 5 项打包修复测试、14 项源码检查、11 项合成 deb 检查、固定上游文件补丁匹配/幂等检查、工作流/ZIP 检查。Windows 不具备该 macOS Perl 打包环境，真实 dm.pl 合成包回归已加入 Actions，尚未在本机执行；完整 Actions 需新提交的实际运行结果确认。

摄像头替换/两路混音仍未真机验证。核心 Objective-C/C++ 文件未改，不将打包修正当成功能完成。

使用：上传 OBSBridge-source-0.2.4-packaging-fix.zip，并用配套 GitHub工作流-0.2.4打包属主修正版.txt 替换仓库根工作流。提交后运行新的 Actions；重新运行旧失败记录会使用旧提交，不会拿到修正。

公开源码：
- https://github.com/theos/dm.pl/blob/d9a3b72e274226dd2823c0a7c1d6d05099f4f51c/dm.pl
- https://github.com/Perl/perl5/blob/blead/cpan/Archive-Tar/lib/Archive/Tar/File.pm （chown 设置名称字段，uid/gid 独立字段）
